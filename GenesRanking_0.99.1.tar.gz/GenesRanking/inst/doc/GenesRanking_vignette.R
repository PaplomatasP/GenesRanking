## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----sessionInfo, warning=FALSE, message=FALSE,results='hide'-----------------
library(GenesRanking)
sessionInfo()

## ----Filter_FS_Methods, warning=FALSE, message=FALSE--------------------------
# load example data
data(ExampleDataset)
data(Labels)

# apply Filter_FS_Methods
FS_filtered_data <- Filter_FS_Methods(ExampleDataset, Labels, 
                                    n_genes_to_keep=100, 
                                    method="WaldTest",
                                    LogTransformation=TRUE,
                                    HighVariableFIlter=TRUE,
                                    n_features=2000)




## ----ML_FS_Methods, warning=FALSE, message=FALSE------------------------------
# apply ML_FS_Methods
ML_filtered_data <- ML_FS_Methods(ExampleDataset, Labels, 
                                  n_genes_to_keep=100, 
                                  method="PAM",
                                  LogTransformation=TRUE,
                                  HighVariableFIlter=TRUE,
                                  n_features=1000)


## ----Examine Results----------------------------------------------------------

# The names of the list elements provide an overview of the different components of the results:
names(ML_filtered_data)

# For instance, let's take a look at the 'Important_Features' element, which contains the dominant genes identified by the method:
head(ML_filtered_data$Important_Features, 10)

# Another important element could be the 'Feature_Importance_Score', which quantifies the importance of each feature:
head(ML_filtered_data$Feature_Importance_Score, 10)

